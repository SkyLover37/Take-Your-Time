
#include "SkillExperienceBuffer.h"
#include "version.h"
#include <stddef.h>
#include <cmath>

using namespace RE::BSScript;
using namespace SKSE;
using namespace SKSE::log;
using namespace SKSE::stl;

namespace {
    const std::string PapyrusClassName = "SleepToGainExperience";

    struct Settings {
        std::uint32_t enableSleepTimeRequirement : 1;
        std::uint32_t : 31;
        float percentExpRequiresSleep;
        float minDaysSleepNeeded;
        float interuptedPenaltyPercent;

        Settings() { ZeroMemory(this, sizeof(Settings)); }
    };

    Settings g_settings;
    SkillExperienceBuffer g_experienceBuffer;
    /**
     * Setup logging.
     *
     * <p>
     * Logging is important to track issues. CommonLibSSE bundles functionality for spdlog, a common C++ logging
     * framework. Here we initialize it, using values from the configuration file. This includes support for a debug
     * logger that shows output in your IDE when it has a debugger attached to Skyrim, as well as a file logger which
     * writes data to the standard SKSE logging directory at <code>Documents/My Games/Skyrim Special Edition/SKSE</code>
     * (or <code>Skyrim VR</code> if you are using VR).
     * </p>
     */
    void InitializeLogging() {
        auto path = log_directory();
        if (!path) {
            report_and_fail("Unable to lookup SKSE logs directory.");
        }
        *path /= PluginDeclaration::GetSingleton()->GetName();
        *path += L".log";

        std::shared_ptr<spdlog::logger> log;
        if (IsDebuggerPresent()) {
            log = std::make_shared<spdlog::logger>(
                "Global", std::make_shared<spdlog::sinks::msvc_sink_mt>());
        } else {
            log = std::make_shared<spdlog::logger>(
                "Global", std::make_shared<spdlog::sinks::basic_file_sink_mt>(path->string(), true));
        }
        log->set_level(spdlog::level::level_enum::debug);
        log->flush_on(spdlog::level::level_enum::trace);

        spdlog::set_default_logger(std::move(log));
        spdlog::set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%n] [%l] [%t] [%s:%#] %v");
    }
    

    

    void PlayerCharacter_AdvanceSkill_Hooked(RE::PlayerCharacter* _this, RE::ActorValue skillId, float points,
                                             std::uint32_t unk1, std::uint32_t unk2) {
        static const std::string ConsoleMenu = "Console";
        static const std::string ConsoleNativeUIMenu = "Console Native UI Menu";

        auto menuManager = RE::UI::GetSingleton();

        if (skillId >= FirstSkillId && skillId <= LastSkillId && _this == RE::PlayerCharacter::GetSingleton()) //&&
            //menuManager && !menuManager->IsMenuOpen(ConsoleMenu) && !menuManager->IsMenuOpen(ConsoleNativeUIMenu))
            
           
        {
            
            g_experienceBuffer.addExperience(skillId, g_settings.percentExpRequiresSleep * points);

            // call the original function but with points = 0
            // not sure what effect not calling it might have

            PlayerCharacter_AdvanceSkill(_this, skillId, (1.0f - g_settings.percentExpRequiresSleep) * points, unk1,
                                         unk2);
        } else
            PlayerCharacter_AdvanceSkill(_this, skillId, points, unk1, unk2);
        std::uint32_t logID = static_cast<std::uint32_t>(skillId);
        logger::debug("AdvanceSkill_Hooked end {0} {1} {2}", logID, unk1, unk2);
    }
    void Serialization_Revert(SKSE::SerializationInterface*) {
        ZeroMemory(&g_experienceBuffer, sizeof(g_experienceBuffer));
    }

    constexpr std::uint32_t serializationDataVersion = 1;

    void Serialization_Save(SKSE::SerializationInterface* serializationInterface) {
        logger::info("Serialization_Save begin");

        if (serializationInterface->OpenRecord('DATA', serializationDataVersion)) {
            serializationInterface->WriteRecordData(&g_experienceBuffer, sizeof(g_experienceBuffer));
        }

        logger::info("Serialization_Save end");
    }

    void Serialization_Load(SKSE::SerializationInterface* serializationInterface) {
        logger::info("Serialization_Load begin");

        std::uint32_t type;
        std::uint32_t version;
        std::uint32_t length;

        bool error = false;

        while (!error && serializationInterface->GetNextRecordInfo(type, version, length)) {
            if (type == 'DATA') {
                if (version == serializationDataVersion) {
                    if (length == sizeof(g_experienceBuffer)) {
                        serializationInterface->ReadRecordData(&g_experienceBuffer, length);
                        logger::info("read data");
                    }
#ifndef SKILLEXPERIENCEBUFFER_NOEXPERIMENTAL
                    else if (length == sizeof(g_experienceBuffer.expBuf)) {
                        serializationInterface->ReadRecordData(&g_experienceBuffer, length);
                        logger::info("read data in old format");
                    }
#endif
                    else {
                        logger::info("empty or invalid data");
                    }
                } else {
                    error = true;
                    logger::info(FMT_STRING("version mismatch! read data version is {}, expected {}"), version,
                                 serializationDataVersion);
                }
            } else {
                logger::info(FMT_STRING("unhandled type {:x}"), type);
                error = true;
            }
        }

        logger::info("Serialization_Load end");
    }

    float GetBufferedPointsBySkill(RE::StaticFunctionTag*, RE::BSFixedString skillName) {
        auto skillId = RE::ActorValueList::GetSingleton()->LookupActorValueByName(skillName.data());

        if (skillId >= FirstSkillId && skillId <= LastSkillId) return g_experienceBuffer.getExperience(skillId);

        return 0.0f;
    }

    void FlushBufferedExperience(RE::StaticFunctionTag*, float daysSlept, bool interupted) {
        g_experienceBuffer.flushExperience(
            (g_settings.enableSleepTimeRequirement ? fminf(1.0f, daysSlept / g_settings.minDaysSleepNeeded) : 1.0f) *
            (interupted ? g_settings.interuptedPenaltyPercent : 1.0f));
    }

    void FlushBufferedExperienceBySkill(RE::StaticFunctionTag*, RE::BSFixedString skillName, float daysSlept,
                                        bool interupted) {
        auto skillId = RE::ActorValueList::GetSingleton()->LookupActorValueByName(skillName.data());

        if (skillId >= FirstSkillId && skillId <= LastSkillId)
            g_experienceBuffer.flushExperienceBySkill(
                skillId, (g_settings.enableSleepTimeRequirement ? fminf(1.0f, daysSlept / g_settings.minDaysSleepNeeded)
                                                                : 1.0f) *
                             (interupted ? g_settings.interuptedPenaltyPercent : 1.0f));
    }

    void MultiplyBufferedExperience(RE::StaticFunctionTag*, float value) { g_experienceBuffer.multExperience(value); }

    void MultiplyBufferedExperienceBySkill(RE::StaticFunctionTag*, RE::BSFixedString skillName, float value) {
        auto skillId = RE::ActorValueList::GetSingleton()->LookupActorValueByName(skillName.data());

        if (skillId >= FirstSkillId && skillId <= LastSkillId) g_experienceBuffer.multExperienceBySkill(skillId, value);
    }

    void ClearBufferedExperience(RE::StaticFunctionTag*) { g_experienceBuffer.clear(); }

    void ClearBufferedExperienceBySkill(RE::StaticFunctionTag*, RE::BSFixedString skillName) {
        auto skillId = RE::ActorValueList::GetSingleton()->LookupActorValueByName(skillName.data());

        if (skillId >= FirstSkillId && skillId <= LastSkillId) g_experienceBuffer.clearBySkill(skillId);
    }
    bool RegisterFuncs(RE::BSScript::IVirtualMachine* registry) {
        registry->RegisterFunction("GetBufferedPointsBySkill", PapyrusClassName, GetBufferedPointsBySkill);

        registry->RegisterFunction("FlushBufferedExperience", PapyrusClassName, FlushBufferedExperience);

        registry->RegisterFunction("FlushBufferedExperienceBySkill", PapyrusClassName, FlushBufferedExperienceBySkill);

        registry->RegisterFunction("MultiplyBufferedExperience", PapyrusClassName, MultiplyBufferedExperience);

        registry->RegisterFunction("MultiplyBufferedExperienceBySkill", PapyrusClassName,
                                   MultiplyBufferedExperienceBySkill);

        registry->RegisterFunction("ClearBufferedExperience", PapyrusClassName, ClearBufferedExperience);

        registry->RegisterFunction("ClearBufferedExperienceBySkill", PapyrusClassName, ClearBufferedExperienceBySkill,
                                   registry);

        logger::info("ALL Papyrus Functions Registery!");

        return true;
    }
    /**
     * Initialize our Papyrus extensions.
     *
     * <p>
     * A common use of SKSE is to add new Papyrus functions. You can call a registration callback to do this. This
     * callback will not necessarily be called immediately, if the Papyrus VM has not been initialized yet (in that case
     * it's execution is delayed until the VM is available).
     * </p>
     *
     * <p>
     * You can call the <code>Register</code> function as many times as you want and at any time you want to register
     * additional functions.
     * </p>
     */
    void InitializePapyrus() {
        log::trace("Initializing Papyrus binding...");
        if (GetPapyrusInterface()->Register(RegisterFuncs)) {
            log::debug("Papyrus functions bound.");
        } else {
            stl::report_and_fail("Failure to register Papyrus bindings.");
        }
    }
    /**
     * Register to listen for messages.
     *
     * <p>
     * SKSE has a messaging system to allow for loosely coupled messaging. This means you don't need to know about or
     * link with a message sender to receive their messages. SKSE itself will send messages for common Skyrim lifecycle
     * events, such as when SKSE plugins are done loading, or when all ESP plugins are loaded.
     * </p>
     *
     * <p>
     * Here we register a listener for SKSE itself (because we have not specified a message source). Plugins can send
     * their own messages that other plugins can listen for as well, although that is not demonstrated in this example
     * and is not common.
     * </p>
     *
     * <p>
     * The data included in the message is provided as only a void pointer. It's type depends entirely on the type of
     * message, and some messages have no data (<code>dataLen</code> will be zero).
     * </p>
     */
    inline constexpr REL::ID Vtbl(static_cast<std::uint64_t>(208040));
    void InitializeMessaging() {
        if (!GetMessagingInterface()->RegisterListener([](MessagingInterface::Message* message) {
            switch (message->type) {
                // Skyrim lifecycle events.
                case MessagingInterface::kPostLoad: // Called after all plugins have finished running SKSEPlugin_Load.
                    // It is now safe to do multithreaded operations, or operations against other plugins.
                case MessagingInterface::kPostPostLoad: // Called after all kPostLoad message handlers have run.
                case MessagingInterface::kInputLoaded: // Called when all game data has been found.
                    break;
                case MessagingInterface::kDataLoaded: {  // All ESM/ESL/ESP plugins have loaded, main menu is now
                                                         // active.
                    // It is now safe to access form data.
                    // All forms are loaded
                    logger::info("kMessage_DataLoaded");

                    auto g_dataHandler = RE::TESDataHandler::GetSingleton();
                   if ((g_dataHandler)->LookupModByName("SleepToGainExperience.esp") ||
                        (g_dataHandler)->LookupModByName("SleepToGainExperience.esl")) {
                        REL::Relocation<std::uintptr_t> PCvtbl(Vtbl);

                        PlayerCharacter_AdvanceSkill = PCvtbl.write_vfunc(0xF7, PlayerCharacter_AdvanceSkill_Hooked);
                   } else
                        logger::info("game plugin not enabled");
                    break;
                }
                // Skyrim game events.
                case MessagingInterface::kNewGame: // Player starts a new game from main menu.
                case MessagingInterface::kPreLoadGame: // Player selected a game to load, but it hasn't loaded yet.
                    // Data will be the name of the loaded save.
                case MessagingInterface::kPostLoadGame: {  // Player's selected save game has finished loading.
                    auto* form =
                        RE::TESDataHandler::GetSingleton()->LookupForm<RE::TESObjectWEAP>(0x013998, "Skyrim.esm");
                    auto factory = RE::IFormFactory::GetConcreteFormFactoryByType<RE::TESObjectWEAP>();
                    auto weaponForm = form->CreateDuplicateForm(false, nullptr);
                   auto Weapon = weaponForm->As<RE::TESObjectWEAP>();
                    logger::debug("")
                    RE::PlayerCharacter::GetSingleton()->AddObjectToContainer(Weapon, nullptr, 1, nullptr);
                    break;
                }
                    // Data will be a boolean indicating whether the load was successful.
                case MessagingInterface::kSaveGame: // The player has saved a game.
                    // Data will be the save name.
                case MessagingInterface::kDeleteGame: // The player deleted a saved game from within the load menu.
                    break;
            }
        })) {
            stl::report_and_fail("Unable to register message listener.");
        }
    }
}  // namespace

/**
 * This if the main callback for initializing your SKSE plugin, called just before Skyrim runs its main function.
 *
 * <p>
 * This is your main entry point to your plugin, where you should initialize everything you need. Many things can't be
 * done yet here, since Skyrim has not initialized and the Windows loader lock is not released (so don't do any
 * multithreading). But you can register to listen for messages for later stages of Skyrim startup to perform such
 * tasks.
 * </p>
 */
SKSEPluginLoad(const LoadInterface* skse) {
    InitializeLogging();

    auto* plugin = PluginDeclaration::GetSingleton();
    auto version = plugin->GetVersion();
    log::info("{} {} is loading...", plugin->GetName(), version);


    Init(skse);

    char stringBuffer[16];
    // configuration
    constexpr const char* configFileName = "Data\\SKSE\\Plugins\\SleepToGainExperience.ini";
    constexpr const char* sectionName = "General";

    // general
    g_settings.enableSleepTimeRequirement = GetPrivateProfileIntA(sectionName, "bEnableSleepTimeRequirement", 0, configFileName);

    g_settings.minDaysSleepNeeded = fabsf((float)GetPrivateProfileIntA(sectionName, "iMinHoursSleepNeeded", 7, configFileName)) / 24.0f;

    GetPrivateProfileStringA(sectionName, "fPercentRequiresSleep", "1.0", stringBuffer, sizeof(stringBuffer),configFileName);

    g_settings.percentExpRequiresSleep = fminf(1.0f, fabsf(strtof(stringBuffer, nullptr)));

    GetPrivateProfileStringA(sectionName, "fInteruptedPenaltyPercent", "1.0", stringBuffer, sizeof(stringBuffer), configFileName);

    g_settings.interuptedPenaltyPercent = fminf(1.0f, fabsf(strtof(stringBuffer, nullptr)));
    InitializeMessaging();
    InitializePapyrus();
    auto g_serialization = SKSE::GetSerializationInterface();

    if (!g_serialization) {
        logger::error("Serialization Interface Not Found!");
        return false;
    }

    g_serialization->SetUniqueID('StGE');

    g_serialization->SetRevertCallback(Serialization_Revert);
    g_serialization->SetSaveCallback(Serialization_Save);
    g_serialization->SetLoadCallback(Serialization_Load);
    log::info("{} has finished loading.", plugin->GetName());
    return true;
}
